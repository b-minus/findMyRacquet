import static spark.Spark.*;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.sql.*;


public class Main {
    static final String JDBC_Driver = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/racquetsdb";
    static final String user = "me";
    static final String pw = "OSLaker8397!";

    public static void main(String[] args) {

        //RacquetFinderFilter

        //rating and type search
        get("/allRacquets/Rating/*/Type/*", (req, res) -> {
            String uri = req.uri();
            String type = "";
            if (uri.endsWith("Control")) {
                type = "control";
            } else if(uri.endsWith("Power")) {
                type = "power";
            } else{
                res.status(404);
            }
            String newuri = uri.substring(0, 24));
            String ratingStr = "";
            double rating = 0.0;
            if(newuri.endsWith(".0") || newuri.endsWith(".5")){
                ratingStr = newuri.substring(newuri.length()-3, newuri.length());
            } else{
                res.status(404);
            }
            rating = Double.valueOf(ratingStr);

        });

        //rating search
        get("/allRacquets/Rating/*", (req, res) -> {
            String uri = req.uri();
            String ratingStr = "";
            double rating = 0.0;
            if(uri.endsWith(".0") || uri.endsWith(".5")){
                ratingStr = uri.substring(uri.length()-3, uri.length());
            } else{
                res.status(404);
            }
            rating = Double.valueOf(ratingStr);
        });

        //type search
        get("/allRacquets/Type/*", (req, res) -> {
            String uri = req.uri();
            String type = "";
            if (uri.endsWith("Control")) {
                type = "control";
            } else if(uri.endsWith("Power")) {
                type = "power";
            } else{
                res.status(404);
            }
        });


        //allRacquets
        get("/allRacquets/*", (req, res) -> {
            ObjectMapper om = new ObjectMapper();
            Connection conn = null;
            Statement stmt = null;

            try {
                //set up database connection
                Class.forName(JDBC_Driver);

                conn = DriverManager.getConnection(DB_URL, user, pw);
                stmt = conn.createStatement();

                //find racquets based on rating search
                ServletContext context = getServletContext();
                Comparator comp = (Comparator) context.getAttribute("rating");

                String sqlStr = "select * from racquets";

                //get search from database
                ResultSet rset = stmt.executeQuery(sqlStr);

                AllRacquets all = new AllRacquets();

                //for each racquet in search
                while (rset.next()) {
                    String name = rset.getString("name");
                    double rating = rset.getDouble("rating");
                    String type = rset.getString("type");
                    double price = rset.getDouble("price");

                    //create racquet instance and add to array for output
                    Racquet current = new Racquet(name, rating, type, price);
                    all.addRacquet(current);
                }
                //save array in session
                context.setAttribute("all", all);

                stmt.close();
                conn.close();
                rset.close();
            }
            //SQL Exception catch
            catch(SQLException se){
                se.printStackTrace();
                out.close();
            }
            //Class Exception catch
            catch(Exception e){
                e.printStackTrace();
                out.close();
            }
            finally{
                out.close();
            }
        });

        post("/allRacquets/*", (req, res) -> {
            //set up to read input JSON
            StringBuilder builder = new StringBuilder();
            BufferedReader reader = req.getReader();
            String input;
            while((input = reader.readLine()) != null){
                builder.append(input);
            }
            //build input as a String
            String data = builder.toString();

            res.setContentType("application/json; charset=UTF-8");
            PrintWriter out = res.getWriter();

            ObjectMapper om = new ObjectMapper();
        });


        //myRacquets
        get("/myRacquets/*", (req, res) -> {
            res.setContentType("application/json; charset=UTF-8");
            PrintWriter out = response.getWriter();

            ObjectMapper om = new ObjectMapper();

            try{
                //get favorite racquets array from session
                ServletContext context = getServletContext();
                FavRacquets favs = (FavRacquets)context.getAttribute("myRacquets");
                Racquet[] mine = favs.getArray();

                //output in JSON format
                out.println("[");

                //if first spot is filled, output first racquet
                if(mine[0] != null){
                    String output = om.writeValueAsString(mine[0]);
                    out.print("   " + output);
                }

                //output rest of favorite racquets if they exist
                for(int x = 1; x < 19; x++){
                    if(mine[x] != null){
                        String output = om.writeValueAsString(mine[x]);
                        out.println(",");
                        out.print("   " + output);
                    }
                }
                //finish JSON array
                out.println("\n]");
            }
            finally{
                out.close();
            }
        });

        delete("/myRacquets/*", (req, res) -> {
            //take in JSON input
            StringBuilder builder = new StringBuilder();
            BufferedReader reader = req.getReader();
            String input;
            while((input = reader.readLine()) != null) {
                builder.append(input);
            }
            //set input as a String
            String data = builder.toString();

            res.setContentType("application/json; charset=UTF-8");
            PrintWriter out = res.getWriter();

            ObjectMapper om = new ObjectMapper();

            try{
                //create racquet based on input
                Racquet delete = om.readValue(data, Racquet.class);

                //search through favorites list, and delete if it exists
                ServletContext context = getServletContext();
                FavRacquets mine = (FavRacquets) context.getAttribute("myRacquets");
                String output = om.writeValueAsString(mine.deleteRacquet(delete));
                out.println(output);
                context.setAttribute("myRacquets", mine);
            }
            finally{
                out.close();
            }
        });

    }
}