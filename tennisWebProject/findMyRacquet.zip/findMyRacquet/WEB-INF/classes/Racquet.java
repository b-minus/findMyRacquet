public class Racquet{
  String name;
  double rating;
  String type;
  double price;
  int amount;

  public Racquet(){
  }

  public Racquet(String n){
    name = n;
  }

  public Racquet(String n, double r, String t, double p) {
    name = n;
    rating = r;
    type = t;
    price = p;
    amount = 1;
  }

  public String getName(){
    return name;
  }
  public double getRating(){
    return rating;
  }
  public String getType(){
    return type;
  }
  public double getPrice(){
    return price;
  }
  public int getAmount(){
    return amount;
  }
  public void setAmount(int a){
    amount = a;
  }

  @Override
  public String toString(){
    return "Prince";
  }
}
