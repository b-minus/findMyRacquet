import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class allRacquetsServlet extends HttpServlet {
  Racquet test = new Racquet("Prince", 3.5, "Control", 159.99);
  Racquet test2 = new Racquet("Wilson", 3.0, "Power", 119.99);

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    response.setContentType("application/json; charset=UTF-8");
    PrintWriter out = response.getWriter();

    ObjectMapper om = new ObjectMapper();

    try{
        String output = om.writeValueAsString(test);

        out.println("[ ");
        out.println("   " + output + ",");

        output = om.writeValueAsString(test2);

        out.println("   " + output);
        out.println("]");
    }
    finally{
        out.close();
    }
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

    StringBuilder builder = new StringBuilder();
    BufferedReader reader = request.getReader();
    String input;
    while((input = reader.readLine()) != null){
        builder.append(input);
    }
    String data = builder.toString();

    response.setContentType("application/json; charset=UTF-8");
    PrintWriter out = response.getWriter();

    ObjectMapper om = new ObjectMapper();

    try{
        Racquet rac = om.readValue(data, Racquet.class);

        if(rac.getName().equals(test.getName())) {
            out.println("Added to your list!");
            ServletContext context = getServletContext();
            context.setAttribute("racquet1", test);
        }
        else if(rac.getName().equals(test2.getName())) {
            out.println("Added to your list!");
            ServletContext context = getServletContext();
            context.setAttribute("racquet1", test2);
        }
        else{
            out.println("No racquet name exists.");
        }
    }
    finally{
        out.close();
    }
  }

}
