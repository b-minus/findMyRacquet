import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class ratingFilter implements Filter {
    ServletContext context;

    public void init(FilterConfig arg) throws ServletException {
        this.context = arg.getServletContext();
        this.context.log("Filter Initialized");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        String uri = req.getRequestURI();

        if(uri.endsWith(".5") || uri.endsWith(".0")) {
            String ratingStr = uri.substring(uri.length() - 3, uri.length());
            double rating = Double.valueOf(ratingStr);
            RequestDispatcher forw = req.getRequestDispatcher("/allRacquets/ratingServ");
            forw.forward(req, resp);
        }
        else{
            chain.doFilter(req, resp);
        }
    }

    public void destroy(){}
}