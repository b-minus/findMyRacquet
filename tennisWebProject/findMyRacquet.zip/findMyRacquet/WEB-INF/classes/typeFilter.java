import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class typeFilter implements Filter {
    ServletContext context;

    public void init(FilterConfig arg) throws ServletException {
        this.context = arg.getServletContext();
        this.context.log("Filter Initialized");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        String uri = req.getRequestURI();

        String type = "null";
        if(uri.endsWith("Control") || uri.endsWith("Power")) {
            if(uri.endsWith("Control")) {
                type = "Control";
            } else if(uri.endsWith("Power")) {
                type = "Power";
            }
            RequestDispatcher forw = req.getRequestDispatcher("/all/Racquets/typeServ");
            forw.forward(req, resp);
        }
        else{
            chain.doFilter(req, resp);
        }
    }

    public void destroy(){}
}