import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class myRacquetsServlet extends HttpServlet {

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    response.setContentType("application/json; charset=UTF-8");
    PrintWriter out = response.getWriter();

    ObjectMapper om = new ObjectMapper();

    try{
      out.println("Your Racquets:");
      ServletContext context = getServletContext();
      String output = om.writeValueAsString(context.getAttribute("racquet1"));
      out.println(output);
    }
    finally{
      out.close();
    }
  }

  public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    StringBuilder builder = new StringBuilder();
    BufferedReader reader = request.getReader();
    String input;
    while((input = reader.readLine()) != null) {
      builder.append(input);
    }
    String data = builder.toString();

    response.setContentType("application/json; charset=UTF-8");
    PrintWriter out = response.getWriter();

    ObjectMapper om = new ObjectMapper();

    try{
      Racquet rac = om.readValue(data, Racquet.class);

      ServletContext context = getServletContext();
      Racquet comp = (Racquet) context.getAttribute("racquet1");
      if(rac.getName().equals(comp.getName())) {
        context.setAttribute("racquet1", null);
        out.println("Racquet deleted.");
      }
      else
        out.println("No racquet exists in your favorites.");
    }
    finally{
      out.close();
    }
  }

}
