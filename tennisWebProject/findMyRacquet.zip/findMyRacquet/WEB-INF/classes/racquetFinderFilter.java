import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class racquetFinderFilter implements Filter {
    ServletContext context;

    public void init(FilterConfig arg) throws ServletException {
        this.context = arg.getServletContext();
        this.context.log("Filter Initialized");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        String uri = req.getRequestURI();

        String newUri = "null";
        if(uri.endsWith(".5") || uri.endsWith(".0")) {
            RequestDispatcher forw = req.getRequestDispatcher("/allRacquets/rating");
            forw.forward(req, resp);
        }
        else if(uri.endsWith("Control") || uri.endsWith("Power")) {
            if(uri.endsWith("Control")) {
                newUri = uri.substring(0, uri.indexOf('C'));
            } else if(uri.endsWith("Power")){
                newUri = uri.substring(0, uri.indexOf('P'));
            }
            RequestDispatcher forw = req.getRequestDispatcher(newUri + "/type");
            forw.forward(req, resp);
        }
        else{
            chain.doFilter(req, resp);
        }
    }

    public void destroy(){}
}
